import rospy
from geometry_msgs.msg import Twist
from kobuki_msgs.msg import BumperEvent
from kobuki_msgs.msg import WheelDropEvent
from sensor_msgs.msg import LaserScan
import math
from math import radians

class FindGap():
    def __init__(self):
        # initiliaze
        self.gapPublisher = rospy.Publisher('/gapscan', LaserScan)
        rospy.init_node('FindGap', anonymous=False)

        # What function to call when you ctrl + c   
        rospy.on_shutdown(self.shutdown)
        
        # Laserscan Subscribers
        rospy.Subscriber("/scan", LaserScan, self.LaserScanCallback)
        self.gapArray = []
        self.gapToPublish = []
        self.startIndex = []
        self.endIndex = []

        
        # as long as you haven't ctrl + c keeping doing...
        while not rospy.is_shutdown():
            pass
        # Is this necessary?
        rospy.spin()
                        
        
    def LaserScanCallback(self, laserscan):
        self.gapArray = []
        self.gapToPublish = []
        self.MakeGapArray(laserscan)
        [self.startIndex, self.endIndex] = self.GapFinder()

        #Publish to the gapscan topic.
        self.MakeGapToPublish()
        gapMessage = laserscan
        gapMessage.ranges = self.gapToPublish
        self.gapPublisher.publish(gapMessage)
        rospy.loginfo(str(self.startIndex) + '  ' + str(self.endIndex))

    def MakeGapToPublish(self):
    	entries = len(self.gapArray)
    	for entry in range(0, entries):
    		if self.gapArray[entry] == 0:
    			self.gapToPublish.append(1)
    		else:
    			self.gapToPublish.append(0)

    def MakeGapArray(self, laserscan):
        entries = len(laserscan.ranges)

        for entry in range(0, entries):
            #Deal with NaNs better
            if math.isnan(laserscan.ranges[entry]):
                if (0 < entry) & (entry < entries-1): # all middle values
                    if (math.isnan(laserscan.ranges[entry+1])):
                        self.gapArray.append(0)
                    elif (math.isnan(laserscan.ranges[entry-1])):
                        self.gapArray.append(0)
                    else:
                        value = (laserscan.ranges[entry-1] + laserscan.ranges[entry+1])/2
                        self.gapArray.append(value if value < 3 else 0)  
                elif (entry == 0): #first value
                    if (math.isnan(laserscan.ranges[entry+1])):
                        self.gapArray.append(0)
                    else:
                        self.gapArray.append(laserscan.ranges[entry+1])
                else: #last value
                    if (math.isnan(laserscan.ranges[entry-1])):
                        self.gapArray.append(0)
                    else:
                        self.gapArray.append(laserscan.ranges[entry-1])

            elif (laserscan.ranges[entry] > 3):
                self.gapArray.append(0)
            else:
                self.gapArray.append(laserscan.ranges[entry])

    def GapFinder(self):
        startIndex = 0
        endIndex = 0
        prevIndex = 0
        maxZeroLength = 0
        curZeroLength = 0
        for curIndex in range(0, len(self.gapArray)):
            if self.gapArray[curIndex] == 0:
                curZeroLength += 1
                prevIndex = curIndex
                if curIndex == (len(self.gapArray) - 1):
                    if (curZeroLength > maxZeroLength):
                        maxZeroLength = curZeroLength
                        endIndex = curIndex
                        curZeroLegnth = 0
            if self.gapArray[curIndex] is not 0:
                if (curZeroLength > maxZeroLength):
                    maxZeroLength = curZeroLength
                    endIndex = prevIndex
                    curZeroLength = 0
        return [(endIndex - maxZeroLength + 1), endIndex]


    def shutdown(self):
        # stop turtlebot
        rospy.loginfo("Stop TurtleBot")
        # a default Twist has linear.x of 0 & angular.z of 0.  So it'll stop TurtleBot
        self.cmd_vel.publish(Twist())
        # sleep just makes sure TurtleBot receives the stop comm& prior to shutting down the script
        rospy.sleep(1)
 
if __name__ == '__main__':
    #try:
    FindGap()
    #except:
     #   rospy.loginfo("GoForward node terminated.")
